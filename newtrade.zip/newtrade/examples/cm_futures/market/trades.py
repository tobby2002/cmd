#!/usr/bin/env python
import logging
from binancefutures.cm_futures import CMFutures
from binancefutures.lib.utils import config_logging

config_logging(logging, logging.DEBUG)

cm_futures_client = CMFutures()

logging.info(cm_futures_client.trades("BTCUSD_PERP", limit=500))
